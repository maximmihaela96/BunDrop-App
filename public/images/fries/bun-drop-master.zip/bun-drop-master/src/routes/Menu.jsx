import React from "react";
import MenuList from "../components/MenuList";

function Menu() {
  return (
    <div>
      <MenuList />
    </div>
  );
}

export default Menu;
